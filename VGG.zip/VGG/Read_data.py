# coding: utf-8
import numpy as  np
import collections
from utils import _read_train_images


class DataSet(object):

    def __init__(self,
                 data,
                 labels,
                 one_hot=False,
                 dtype=np.float32,
                 reshape=False):
            
           
        self._num_examples=data.shape[0]
            #print(self._num_examples)
        if reshape:
            #assert data.shape[2] ==1
            data = data.reshape (data.shape[0],
                                      data.shape[1], data.shape[2], data.shape[3])
        if dtype == np.float32:
            data = data.astype(np.float32)
        self._data = data
        self._labels= labels
        self._epochs_completed =0
        self._index_in_epoch =0
        
    @property
    def data(self):
        return self._data
            
    @property
    def labels(self):
        return self._labels
            
    @property
    def num_exanples(self):
        return self._num_examples
            
    @property
    def epochs_completed(self):
        return self._epochs_completed
        
        
    def next_batch(self, batch_size, shuffle =True):
        """ Return the bext 'batch_size' examples from this data set."""
        start=self._index_in_epoch
                
        #Shuffle for the first epoch
                
        if self._epochs_completed ==0 and start ==0 and shuffle:
            perm0=np.arange(self._num_examples)
            np.random.shuffle(perm0)
            self._data=self.data[perm0]
            self._labels=self.labels[perm0]
                    
        #go to the next epoch
        if start+batch_size > self._num_examples:
            #finished epoch
            self._epochs_completed +=1
            #get the rest examples in this epoch
            rest_num_examples = self._num_examples - start
            data_rest_part = self.data[start : self._num_examples]
            labels_rest_part =self._labels[start: self._num_examples]
            #Shuffle the data      
            if shuffle:
                perm=np.arange(self._num_examples)
                np.random.shuffle(perm)
                self._data=self.data[perm]
                self._labels=self.labels[perm]
                        
            # Start next epoch
            start = 0
            self._index_in_epoch =batch_size-rest_num_examples
            end=self._index_in_epoch
            data_new_part = self._data[start: end]
            labels_new_part = self._labels[start: end]
            return np.concatenate((data_rest_part, data_new_part), axis=0),np.concatenate((labels_rest_part, labels_new_part), axis=0)                    
        else:
            self._index_in_epoch += batch_size
            end=self._index_in_epoch
            return self._data[start: end], self._labels[start: end]
 
     
        
Datasets = collections.namedtuple('Datasets', ['train'])


def read_data_sets(training_data_path, dtype = np.float32):
        """
        data is input into dictionary
        """
        
        data, labels = _read_train_images(training_data_path)
        print(labels)
        train =DataSet(data, labels, dtype =dtype)
    
    
        return Datasets(train=train)
  
  
if __name__ =='__main__':
    
    train_data_path = 'train_data.txt'
    read_data_sets(train_data_path)