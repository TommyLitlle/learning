#coding: utf-8


import tensorflow as tf


def conv_3x3(inputs, num_filter, num_layer):
    
    '''
    :param inputs. inputs for convolutional layer
    :param num_filter. 
    :param filter size, example 1x1, 3x3
    :param stride
    return last convolutional layer
    '''
    layer_list = []
    
    #convolutional layer
    conv = tf.layers.conv2d(inputs, filters = num_filter,
                            kernel_size= [3, 3], padding = 'same') 
    conv = tf.nn.relu(conv)
    
    layer_list.append(conv)
    
    #continuous convolutional layers
    for i in range(num_layer-1):
        
        print("i:", i)
        conv = tf.layers.conv2d(conv, filters=num_filter, 
                                kernel_size=[3,3], padding='same')
        conv = tf.nn.relu(conv)
        layer_list.append(conv)
        
    return layer_list[-1]
 
 
 
def conv_1x1(inputs, num_filter, num_layer):  
    '''
    :param inputs. inputs for convolutional layer
    :param num_filter. 
    :param filter size, example 1x1, 3x3
    :param stride
    return last convolutional layer
    '''
    layer_list = []
    
    #convolutional layer
    conv = tf.layers.conv2d(inputs, filters = num_filter,
                            kernel_size= [1, 1], padding = 'same') 
    conv = tf.nn.relu(conv)
    
    layer_list.append(conv)
    
    #continuous convolutional layers
    for i in range(num_layer-1):
        
        print("i:", i)
        conv = tf.layers.conv2d(conv, filters=num_filter, 
                                kernel_size=[1,1], padding='same')
        conv = tf.nn.relu(conv)
        layer_list.append(conv)
        
    return layer_list[-1]
 
    
def VGGNet(inputs):
    
    '''
    :param. inputs for neural network
    :drop_rate. 
    '''
    # first convolutional layer
    conv = tf.layers.conv2d(inputs, filters=64, kernel_size=[7, 7],
                             padding='same', strides =2)
    conv = tf.nn.relu(conv)
    
    
    first_pool = tf.layers.max_pooling2d(conv, pool_size=[3, 3], 
                                         strides=2, padding='same')

    # 2 continuous convolutional layers
    conv = conv_3x3(first_pool, 64, 2)
    
    second_pool = tf.layers.max_pooling2d(conv, pool_size=[2, 2], 
                                          strides=2, padding='same')

    # 3 continuous convolutional layers
    conv = conv_3x3(second_pool, 128, 3)
    
    three_pool = tf.layers.max_pooling2d(conv, pool_size=[2, 2], 
                                          strides=2, padding='same')
 
    # 3 continuous convolutional layers
    conv = conv_3x3(three_pool, 256, 3)
    
    four_pool = tf.layers.max_pooling2d(conv, pool_size=[2, 2], 
                                          strides=2, padding='same')
  
    # 3 continuous convolutional layers 3*3
    conv = conv_3x3(four_pool, 512, 3)
    
    five_pool = tf.layers.max_pooling2d(conv, pool_size=[2, 2], 
                                          strides=2, padding='same')
    
    conv = conv_1x1(five_pool, 1024, 2)
    
    #global pooling
    global_pool = tf.reduce_mean(conv, [1, 2])
    
    #flatten layer
    flat  =tf.reshape(global_pool,[-1, 1024])
    
    #prediction 
    digit_1 = tf.layers.dense(flat, units=2)
    
    digit_2 = tf.layers.dense(flat, units =2)
    
    return digit_1, digit_2



def loss_func(digit_1, digit_2, digits_labels):
        # loss of 
        digit1_cross_entropy = tf.reduce_mean(tf.losses.sparse_softmax_cross_entropy(labels=digits_labels[:, 0], logits=digit_1))
        digit2_cross_entropy = tf.reduce_mean(tf.losses.sparse_softmax_cross_entropy(labels=digits_labels[:, 1], logits=digit_2))
        loss = digit1_cross_entropy + digit2_cross_entropy 
        return loss