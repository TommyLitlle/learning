#coding: utf-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf
import sys
import time
from Model import VGGNet, loss_func
from Read_data import read_data_sets



class CNN:
    def __init__(self,alpha,batch_size,num_classes, height, width, channel):
        """ Initialize the CNN model
        :param alpha: the learning rate to be used by the model
        :param batch_size : the number of batches to use for training
        :param num_classes: the number of classes in the dataset
        :param num_features: the number of features in the dataset
        """
        
        self.alpha= alpha
        self.batch_size = batch_size
        self.name='CNN'
        self.num_classes = num_classes
        self.height = height
        self.width = width
        self.channel = channel
        
        def __graph__():
        
            #[batch_size, num_features]
            x_input = tf.placeholder(dtype=tf.float32,shape=[None, height, width, channel], name='x_input')
            
            #[batch_size, num_classes*num_labels]
            y_input=tf.placeholder(dtype= tf.int32, shape=[None,num_classes], name='actual_label')
            
            input_layer = tf.reshape(x_input,[-1, height, width, channel])
            
            predicted_logit1, predicted__logit2 = VGGNet(input_layer)
           
           
            
          
            loss = loss_func(digit_1 = predicted_logit1, digit_2 = predicted__logit2, 
                            digits_labels = y_input)
            
            tf.summary.scalar('loss',loss)
            
            optimizer = tf.train.AdamOptimizer(learning_rate=alpha).minimize(loss)
            
            #accuracy
            output_1 = tf.argmax(predicted_logit1, 1)
            output_1 = tf.cast(output_1, tf.int32)
            
            output_2 = tf.argmax(predicted_logit1,1)
            output_2 = tf.cast(output_2, tf.int32)
            #accuracy_one
            correct_pred= tf.equal(output_1, y_input[:,0])
            accuracy_one = tf.reduce_mean(tf.cast(correct_pred, tf.float32))
            
            #accuracy two
            correct_pred= tf.equal(output_2, y_input[:,1])
            accuracy_two = tf.reduce_mean(tf.cast(correct_pred, tf.float32))
            
            tf.summary.scalar('accuracy', accuracy_one)
            
            merged = tf.summary.merge_all()
            
            self.x_input = x_input
            self.y_input  = y_input
            self.digit1=predicted_logit1
            self.digit2 = predicted__logit2
            self.loss = loss
            self.optimizer=optimizer
            self.accuracy_left = accuracy_one
            self.accuracy_right = accuracy_two
            self.merged = merged
            
        sys.stdout.write('\n<log> Building graph...')
        __graph__()
        sys.stdout.write('</log>\n')
        

    def train(self,checkpoint_path, epochs,log_path, train_data, patience):
        
        """Trains the initialized model.
        :param checkpoint_path: The path where to save the trained model.
        :param log_path: The path where to save the TensorBoard logs.
        :param train_data: The training dataset.
        :param test_data: The testing dataset.
        :return: None
        """
        
        if not os.path.exists(path=log_path):
            os.mkdir(log_path)
            
        if not os.path.exists(path=checkpoint_path):
            os.mkdir(checkpoint_path)            
        
        saver= tf.train.Saver(max_to_keep=4)
        
        init = tf.global_variables_initializer()
        
        timestamp = str(time.asctime())
            
        train_writer = tf.summary.FileWriter(logdir=log_path +'-training', graph=tf.get_default_graph())
        
        with tf.Session() as sess:
            
            best_accuracy = 0.0
            sess.run(init)
            
            checkpoint = tf.train.get_checkpoint_state(checkpoint_path)
            
            if checkpoint and checkpoint.model_checkpoint_path:
                saver = tf.train.import_meta_graph(checkpoint.model_checkpoint_path + '.meta')
                saver.restore(sess, tf.train.latest_checkpoint(checkpoint_path))
                
            for index in range(epochs): 
                #train by batch
                batch_features, batch_labels = train_data.next_batch(self.batch_size)
                
                #input dictionary with dropout of 50%
                feed_dict = {self.x_input:batch_features, self.y_input:batch_labels}
                
                # run the train op
                summary, _, loss = sess.run([self.merged, self.optimizer, self.loss], feed_dict=feed_dict)
                
                train_writer.add_summary(summary=summary, global_step=index)
                feed_dict = {self.x_input: batch_features, self.y_input: batch_labels}
               
                # get the accuracy of training
                train_accuracy = sess.run(self.accuracy_left, feed_dict=feed_dict)
                
                print('step: {}, training accuracy : {}, training loss : {}\n'.format(index, train_accuracy, loss))
                
                if train_accuracy >= best_accuracy:
                    best_accuracy = train_accuracy 
                    #dispaly the training accuracy
                    print('step: {}, best accuracy : {}'.format(index, best_accuracy))
                    saver.save(sess, save_path=os.path.join(checkpoint_path, self.name), global_step=index)
      
      
        
    def test_model(self, test_data, checkpoint_path):            
        """
        Parameter 
        -------
        test_data: which is independent to training data
        dropout rate: float, the dropout rate to be used.
        
        """
        test_features= test_data.data
        test_labels = test_data.labels
        
        init = tf.global_variables_initializer()

        with tf.Session() as sess:
            sess.run(init)
            checkpoint = tf.train.get_checkpoint_state(checkpoint_path)
            
            if checkpoint and checkpoint.model_checkpoint_path:
                saver = tf.train.import_meta_graph(checkpoint.model_checkpoint_path +'.meta')
                saver.restore(sess, tf.train.latest_checkpoint(checkpoint_path))
                print("Loades model from {}".format(tf.train.latest_checkpoint(checkpoint_path)))
            feed_dict= {self.x_input:test_features, self.y_input:test_labels}    
            test_accuracy = sess.run(self.accuracy, feed_dict=feed_dict)
            print('Test Accuracy: {}'.format(test_accuracy)) 
         


if __name__ == '__main__':
    
    data=read_data_sets(training_data_path = 'train_data.txt')
    train_data=data.train
    num_classes=2      
    height =448
    width = 448
    channel = 3
    model=CNN(alpha=0.002, batch_size=1, num_classes=num_classes, 
              height = height, width = width, channel = channel)
    model.train(checkpoint_path='C:/tmp/LPconvnet_model6',epochs=1, 
                log_path='C:/tmp/tensorflow/logs',
                train_data=train_data, patience = 2)
   