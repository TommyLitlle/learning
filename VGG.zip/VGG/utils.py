#coding:utf-8
# ==============================================================================
from PIL import Image
from six.moves import urllib
import numpy as np
import pickle as cp
import os
import cv2



train_image_path = 'valid'
train_label_path = 'Training100_Location.csv'

vild_image_path ='valid'

train_data_path =  "train_data.txt"
valid_path = "valid_data.txt"


Width = 448
Height = 448
Depth = 3
NUM_CLASS = 4


VALI_RANDOM_LABEL = False # Want to use random label for validation?

NUM_TRAIN_BATCH = 5 # How many batches of files you want to read in, from 0 to 5)
EPOCH_SIZE = 10000 * NUM_TRAIN_BATCH



def Resize_Image(img, width, height, 
                 method):
    '''
    :param image_input: the name of image
    :param height, width: the size of image is resize
    :param method : the choice to select proper quantization method
    '''
    out = img.resize((width, height), method)
    return out


def read_image_data(file_path):
    
    """
    read all images from folder
    if the folder path does not exist, return file does not exist.
    
    """
    if os.path.exists(file_path):
        print("file directory exists")
        files = os.listdir(file_path) # get the names of all files
        # print(files)
        NO_Examples = len(files)
        
        #print("NO_files",NO_files)
        
       
        count = 0 # get the number of files
        # data return 
        Img_data = np.zeros((NO_Examples, Height, Width, Depth))
        print(Img_data.shape) # Just for testing
        for file in files:
            img = Image.open(file_path+"/"+file)
            img = Resize_Image(img, Height, Width, method = Image.ANTIALIAS)
            Img_data[count,:,:,:] = img
            count += 1
        #print("Store all images in a file successfully")
        #print('Img_data:',Img_data)
        return  Img_data

    else:
        print(" file path does not exist")


def dataframe_from_csv2(label_file_path):
    """
    Read labels with numpy.load_txt()
    """
    labels = np.loadtxt(open(label_file_path),delimiter=",",skiprows=1)
    labels = np.array(labels, dtype = np.float32)
    return labels
        
        
def pickle_train_data(file_path, label_path, pickle_file_path):
    
    """
    Load data
    store data with pickle file
    """
    data = read_image_data(file_path)
    labels = dataframe_from_csv2(label_path)
    
    obj =([data,labels])
    
    f = open(pickle_file_path, 'wb')
    cp.dump(obj, f, protocol=cp.HIGHEST_PROTOCOL)
    f.close()


def pickle_valid_data(file_path, pickle_file_path):
    """
    Load data from file path and convert it into pickle
    """
    data = read_image_data(file_path)
    obj =([data])
     
    f = open(pickle_file_path, 'wb')
    cp.dump(obj, f, protocol=cp.HIGHEST_PROTOCOL)
    f.close()

 

def _read_train_images(path):
    '''
    The training data contains five data batches in total. The validation data has only one
    batch. This function takes the directory of one batch of data and returns the images and
    corresponding labels as numpy arrays
    :param path: the directory of one batch of data
    :param is_random_label: do you want to use random labels?
    :return: image numpy arrays and label numpy arrays
    '''
    fo = open(path, 'rb')
    data, labels = cp.load(fo)
    fo.close()
    data= np.array(data, dtype = np.float32)
    return data, labels


def read_valid_images(path):
    
    fo = open(path, 'rb')
    data = cp.load(fo)
    fo.close()
    data = np.array(data, dtype = np.float32)
    return data
      

def read_in_all_images(address, shuffle=True):
    """
    This function reads all training or validation data, shuffles them if needed, and returns the
    images and the corresponding labels as numpy arrays
    :param address_list: a list of paths of cPickle files
    :return: concatenated numpy array of data and labels. Data are in 4D arrays: [num_images,
    image_height, image_width, image_depth] and labels are in 1D arrays: [num_images]
    """
  
    data, label = _read_train_images(address)

    data = data.astype(np.float32)
    return data, label



def read_validation_data():
    '''
    Read in validation data. Whitening at the same time
    :return: Validation image data as 4D numpy array. Validation labels as 1D numpy array
    '''
    validation_array= read_valid_images(valid_path)

    return validation_array

if  __name__ == '__main__':
    
    pickle_train_data(train_image_path, train_label_path, train_data_path)
    pickle_valid_data(vild_image_path, valid_path)